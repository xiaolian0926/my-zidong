package tkaxv7s.xposed.sesame.util;

public class ClassUtil {

    public static final String PACKAGE_NAME = "com.eg.android.AlipayGphone";

    public static final String CURRENT_USING_SERVICE = "com.alipay.dexaop.power.RuntimePowerService";

    public static final String CURRENT_USING_ACTIVITY = "com.eg.android.AlipayGphone.AlipayLogin";

    public static final String JSON_OBJECT_NAME = "com.alibaba.fastjson.JSONObject";

    public static final String H5PAGE_NAME = "com.alipay.mobile.h5container.api.H5Page";

}
